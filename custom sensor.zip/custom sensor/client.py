import asyncio

from viam.robot.client import RobotClient
from viam.components.sensor import Sensor

from viam.components.camera import Camera
from viam.services.vision import VisionClient

async def connect():
    opts = RobotClient.Options.with_api_key(api_key="API KEY", api_key_id="API KEY ID")
    return await RobotClient.at_address("ADDRESS", opts)


async def main():
    robot = await connect()
    
    myPeopleDetector = VisionClient.from_robot(robot, "myPeopleDetector")
    my_camera = Camera.from_robot(robot, "camera-1")

    print("Resources:")
    print(robot.resource_names)

    sensor = Sensor.from_robot(robot, name="custom_sensor")

    while True:
        img = await my_camera.get_image(mime_type="image/jpeg")
        detections = await myPeopleDetector.get_detections(img)
        found = False
        for d in detections:
            if d.confidence > 0.7 and d.class_name.lower() == "person":
                print("This is a person!")
                found = True
                
        if found:
            #Set the sensor equal to 1
            reading = await sensor.get_readings(extra={"person_value": 1.0})
            print("Person detected!")
            await asyncio.sleep(1)
        else:
            #Set the sensor equal to 0
            reading = await sensor.get_readings(extra={"person_value": 0.0})
            print("No people detected!")
            await asyncio.sleep(1)

    await robot.close()


if __name__ == "__main__":
    asyncio.run(main())
